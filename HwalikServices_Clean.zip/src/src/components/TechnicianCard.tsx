import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star, MapPin } from "lucide-react";

interface TechnicianCardProps {
  id: string;
  name: string;
  serviceType: string;
  rating: string;
  priceRange: string;
  description?: string;
  location?: string;
  onRequestService?: (id: string) => void;
}

export default function TechnicianCard({
  id,
  name,
  serviceType,
  rating,
  priceRange,
  description,
  location = "الرياض",
  onRequestService,
}: TechnicianCardProps) {
  const getServiceTypeArabic = (type: string) => {
    const types: Record<string, string> = {
      plumbing: "سباكة",
      electrical: "كهرباء",
      cleaning: "تنظيف",
      ac: "تكييف",
      painting: "دهان",
      carpentry: "نجارة",
    };
    return types[type] || type;
  };

  return (
    <Card className="p-6 hover-elevate transition-all" data-testid={`card-technician-${id}`}>
      <div className="flex gap-4">
        {/* Avatar */}
        <Avatar className="w-20 h-20">
          <AvatarFallback className="text-2xl bg-primary/10 text-primary">
            {name.charAt(0)}
          </AvatarFallback>
        </Avatar>

        {/* Details */}
        <div className="flex-1">
          <div className="flex items-start justify-between gap-2 mb-2">
            <div>
              <h3 className="text-lg font-semibold mb-1" data-testid={`text-technician-name-${id}`}>
                {name}
              </h3>
              <Badge variant="secondary" data-testid={`badge-service-type-${id}`}>
                {getServiceTypeArabic(serviceType)}
              </Badge>
            </div>
            <div className="flex items-center gap-1 text-yellow-600">
              <Star className="w-4 h-4 fill-current" />
              <span className="font-semibold" data-testid={`text-rating-${id}`}>{rating}</span>
            </div>
          </div>

          {description && (
            <p className="text-sm text-muted-foreground mb-3 line-clamp-2" data-testid={`text-description-${id}`}>
              {description}
            </p>
          )}

          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              <span data-testid={`text-location-${id}`}>{location}</span>
            </div>
            <div className="font-semibold text-foreground" data-testid={`text-price-${id}`}>
              {priceRange} ريال
            </div>
          </div>

          <Button
            className="w-full"
            onClick={() => {
              console.log(`Request service from technician: ${id}`);
              onRequestService?.(id);
            }}
            data-testid={`button-request-service-${id}`}
          >
            طلب خدمة
          </Button>
        </div>
      </div>
    </Card>
  );
}
