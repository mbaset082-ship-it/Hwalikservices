import { Phone, Mail, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-card-border mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold text-primary mb-4" data-testid="text-footer-logo">
              حوليك
            </h3>
            <p className="text-muted-foreground mb-4" data-testid="text-footer-description">
              منصة سعودية موثوقة لربط العملاء بأفضل الفنيين المحترفين في المملكة
            </p>
            <div className="text-sm text-muted-foreground">
              <p>سجل تجاري: 1234567890</p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4" data-testid="text-footer-links-title">روابط سريعة</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <a href="/" className="hover:text-primary transition-colors" data-testid="link-footer-home">
                  الرئيسية
                </a>
              </li>
              <li>
                <a href="/technicians" className="hover:text-primary transition-colors" data-testid="link-footer-technicians">
                  الفنيين
                </a>
              </li>
              <li>
                <a href="/register" className="hover:text-primary transition-colors" data-testid="link-footer-register">
                  تسجيل جديد
                </a>
              </li>
              <li>
                <a href="/about" className="hover:text-primary transition-colors" data-testid="link-footer-about">
                  من نحن
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4" data-testid="text-footer-contact-title">تواصل معنا</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-muted-foreground">
                <Phone className="w-4 h-4" />
                <span data-testid="text-footer-phone">920012345</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <Mail className="w-4 h-4" />
                <span data-testid="text-footer-email">info@hwalik.sa</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span data-testid="text-footer-location">الرياض، المملكة العربية السعودية</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p data-testid="text-footer-copyright">
            © 2025 حوليك. جميع الحقوق محفوظة
          </p>
        </div>
      </div>
    </footer>
  );
}
