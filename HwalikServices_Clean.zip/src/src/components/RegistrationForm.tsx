import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UserCircle, Wrench } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function RegistrationForm() {
  const [, setLocation] = useLocation();
  const { register } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [role, setRole] = useState<"client" | "technician">("client");
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    password: "",
    confirmPassword: "",
    serviceType: "",
    description: "",
    priceRange: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "خطأ",
        description: "كلمة المرور غير متطابقة",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const registrationData: any = {
        name: formData.name,
        phone: formData.phone,
        password: formData.password,
        role,
      };

      if (role === "technician") {
        registrationData.technicianData = {
          serviceType: formData.serviceType,
          description: formData.description,
          priceRange: formData.priceRange,
          rating: "0",
        };
      }

      await register(registrationData);
      
      toast({
        title: "تم إنشاء الحساب بنجاح",
        description: "مرحباً بك في حوليك",
      });
      
      setLocation("/");
    } catch (error) {
      toast({
        title: "خطأ في التسجيل",
        description: error instanceof Error ? error.message : "حدث خطأ غير متوقع",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4 py-8">
      <Card className="w-full max-w-2xl p-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2" data-testid="text-register-title">
            إنشاء حساب جديد
          </h2>
          <p className="text-muted-foreground" data-testid="text-register-subtitle">
            انضم إلى منصة حوليك اليوم
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Role Selection */}
          <div className="space-y-3">
            <Label data-testid="label-role">اختر نوع الحساب</Label>
            <RadioGroup value={role} onValueChange={(value) => setRole(value as "client" | "technician")}>
              <div className="grid grid-cols-2 gap-4">
                <div
                  className={`relative flex flex-col items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    role === "client"
                      ? "border-primary bg-primary/5"
                      : "border-border hover-elevate"
                  }`}
                  onClick={() => setRole("client")}
                  data-testid="option-client"
                >
                  <RadioGroupItem value="client" id="client" className="sr-only" />
                  <UserCircle className="w-12 h-12 text-primary" />
                  <Label htmlFor="client" className="cursor-pointer font-semibold">
                    عميل
                  </Label>
                  <p className="text-xs text-muted-foreground text-center">
                    أطلب الخدمات
                  </p>
                </div>

                <div
                  className={`relative flex flex-col items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    role === "technician"
                      ? "border-primary bg-primary/5"
                      : "border-border hover-elevate"
                  }`}
                  onClick={() => setRole("technician")}
                  data-testid="option-technician"
                >
                  <RadioGroupItem value="technician" id="technician" className="sr-only" />
                  <Wrench className="w-12 h-12 text-primary" />
                  <Label htmlFor="technician" className="cursor-pointer font-semibold">
                    فني
                  </Label>
                  <p className="text-xs text-muted-foreground text-center">
                    قدم الخدمات
                  </p>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name" data-testid="label-name">الاسم الكامل</Label>
            <Input
              id="name"
              type="text"
              placeholder="أدخل اسمك الكامل"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              data-testid="input-name"
            />
          </div>

          {/* Phone */}
          <div className="space-y-2">
            <Label htmlFor="phone" data-testid="label-phone">رقم الجوال</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="05xxxxxxxx"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              required
              data-testid="input-phone"
            />
          </div>

          {/* Technician Fields */}
          {role === "technician" && (
            <>
              <div className="space-y-2">
                <Label htmlFor="serviceType" data-testid="label-service-type">نوع الخدمة</Label>
                <Select
                  value={formData.serviceType}
                  onValueChange={(value) => setFormData({ ...formData, serviceType: value })}
                  required
                >
                  <SelectTrigger id="serviceType" data-testid="select-service-type">
                    <SelectValue placeholder="اختر نوع الخدمة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="plumbing">سباكة</SelectItem>
                    <SelectItem value="electrical">كهرباء</SelectItem>
                    <SelectItem value="cleaning">تنظيف</SelectItem>
                    <SelectItem value="ac">تكييف</SelectItem>
                    <SelectItem value="painting">دهان</SelectItem>
                    <SelectItem value="carpentry">نجارة</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" data-testid="label-description">وصف الخدمة</Label>
                <Textarea
                  id="description"
                  placeholder="اشرح خبرتك وخدماتك..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  required
                  data-testid="textarea-description"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="priceRange" data-testid="label-price-range">نطاق السعر (ريال)</Label>
                <Input
                  id="priceRange"
                  type="text"
                  placeholder="مثال: 100-300"
                  value={formData.priceRange}
                  onChange={(e) => setFormData({ ...formData, priceRange: e.target.value })}
                  required
                  data-testid="input-price-range"
                />
              </div>
            </>
          )}

          {/* Password */}
          <div className="space-y-2">
            <Label htmlFor="password" data-testid="label-password">كلمة المرور</Label>
            <Input
              id="password"
              type="password"
              placeholder="أدخل كلمة المرور"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
              data-testid="input-password"
            />
          </div>

          {/* Confirm Password */}
          <div className="space-y-2">
            <Label htmlFor="confirmPassword" data-testid="label-confirm-password">تأكيد كلمة المرور</Label>
            <Input
              id="confirmPassword"
              type="password"
              placeholder="أعد إدخال كلمة المرور"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              required
              data-testid="input-confirm-password"
            />
          </div>

          {/* Submit Button */}
          <Button 
            type="submit" 
            className="w-full" 
            size="lg" 
            disabled={isLoading}
            data-testid="button-submit"
          >
            {isLoading ? "جاري إنشاء الحساب..." : "إنشاء حساب"}
          </Button>

          {/* Login Link */}
          <p className="text-center text-sm text-muted-foreground">
            لديك حساب بالفعل؟{" "}
            <a href="/login" className="text-primary hover:underline" data-testid="link-login">
              تسجيل الدخول
            </a>
          </p>
        </form>
      </Card>
    </div>
  );
}
