import { Card } from "@/components/ui/card";
import { Wrench, Zap, Sparkles, Wind, Paintbrush, Hammer } from "lucide-react";

const categories = [
  { id: "plumbing", name: "سباكة", icon: Wrench, count: 87, color: "text-blue-600" },
  { id: "electrical", name: "كهرباء", icon: Zap, count: 65, color: "text-yellow-600" },
  { id: "cleaning", name: "تنظيف", icon: Sparkles, count: 120, color: "text-green-600" },
  { id: "ac", name: "تكييف", icon: Wind, count: 54, color: "text-cyan-600" },
  { id: "painting", name: "دهان", icon: Paintbrush, count: 43, color: "text-purple-600" },
  { id: "carpentry", name: "نجارة", icon: Hammer, count: 38, color: "text-orange-600" },
];

export default function ServiceCategories() {
  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-categories-title">
            اختر نوع الخدمة
          </h2>
          <p className="text-lg text-muted-foreground" data-testid="text-categories-subtitle">
            فنيون محترفون في جميع المجالات
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Card
                key={category.id}
                className="p-6 flex flex-col items-center gap-4 cursor-pointer hover-elevate active-elevate-2 transition-all"
                data-testid={`card-category-${category.id}`}
                onClick={() => console.log(`Category selected: ${category.id}`)}
              >
                <div className={`${category.color} bg-muted rounded-full p-4`}>
                  <Icon className="w-8 h-8" />
                </div>
                <div className="text-center">
                  <div className="font-semibold mb-1" data-testid={`text-category-name-${category.id}`}>
                    {category.name}
                  </div>
                  <div className="text-sm text-muted-foreground" data-testid={`text-category-count-${category.id}`}>
                    {category.count} فني
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
