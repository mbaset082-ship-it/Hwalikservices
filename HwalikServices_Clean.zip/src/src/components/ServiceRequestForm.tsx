import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ServiceRequestFormProps {
  technicianId?: string;
  technicianName?: string;
  onSubmit?: (data: { serviceType: string; description: string }) => void;
}

export default function ServiceRequestForm({
  technicianId,
  technicianName,
  onSubmit,
}: ServiceRequestFormProps) {
  const [serviceType, setServiceType] = useState("");
  const [description, setDescription] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Service request submitted:", { technicianId, serviceType, description });
    onSubmit?.({ serviceType, description });
    // TODO: Call API to create service request
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4 py-8">
      <Card className="w-full max-w-2xl p-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2" data-testid="text-request-title">
            طلب خدمة جديدة
          </h2>
          {technicianName && (
            <p className="text-muted-foreground" data-testid="text-technician-name">
              من الفني: {technicianName}
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Service Type */}
          <div className="space-y-2">
            <Label htmlFor="serviceType" data-testid="label-service-type">نوع الخدمة</Label>
            <Select value={serviceType} onValueChange={setServiceType} required>
              <SelectTrigger id="serviceType" data-testid="select-service-type">
                <SelectValue placeholder="اختر نوع الخدمة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="plumbing">سباكة</SelectItem>
                <SelectItem value="electrical">كهرباء</SelectItem>
                <SelectItem value="cleaning">تنظيف</SelectItem>
                <SelectItem value="ac">تكييف</SelectItem>
                <SelectItem value="painting">دهان</SelectItem>
                <SelectItem value="carpentry">نجارة</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" data-testid="label-description">وصف المشكلة</Label>
            <Textarea
              id="description"
              placeholder="اشرح تفاصيل الخدمة المطلوبة..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              required
              data-testid="textarea-description"
            />
            <p className="text-sm text-muted-foreground">
              اشرح المشكلة بالتفصيل لمساعدة الفني على فهم احتياجاتك
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button type="submit" className="flex-1" size="lg" data-testid="button-submit">
              إرسال الطلب
            </Button>
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              size="lg"
              onClick={() => {
                console.log("Cancel clicked");
                window.history.back();
              }}
              data-testid="button-cancel"
            >
              إلغاء
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
