import { Search, UserCheck, CheckCircle } from "lucide-react";

const steps = [
  {
    id: 1,
    icon: Search,
    title: "ابحث عن الفني المناسب",
    description: "تصفح الفنيين المحترفين واختر الأنسب لاحتياجاتك",
  },
  {
    id: 2,
    icon: UserCheck,
    title: "أرسل طلب الخدمة",
    description: "حدد نوع الخدمة واشرح التفاصيل بسهولة",
  },
  {
    id: 3,
    icon: CheckCircle,
    title: "احصل على الخدمة",
    description: "سيقوم الفني بقبول الطلب وتنفيذ الخدمة بجودة عالية",
  },
];

export default function HowItWorks() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-howitworks-title">
            كيف تعمل المنصة؟
          </h2>
          <p className="text-lg text-muted-foreground" data-testid="text-howitworks-subtitle">
            ثلاث خطوات بسيطة للحصول على الخدمة
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.id} className="text-center" data-testid={`step-${step.id}`}>
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 text-primary mb-6">
                  <Icon className="w-10 h-10" />
                </div>
                <div className="relative">
                  <div className="absolute -top-16 right-1/2 translate-x-1/2 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold">
                    {step.id}
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-3" data-testid={`text-step-title-${step.id}`}>
                  {step.title}
                </h3>
                <p className="text-muted-foreground" data-testid={`text-step-description-${step.id}`}>
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
