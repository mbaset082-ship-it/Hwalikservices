import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, User, LogIn, Menu, X, LogOut, LayoutDashboard } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";

export default function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo - right side for RTL */}
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer hover-elevate rounded-md px-3 py-2" data-testid="link-home">
              <div className="text-2xl font-bold text-primary">حوليك</div>
            </div>
          </Link>

          {/* Desktop Navigation - center-right */}
          <div className="hidden md:flex items-center gap-2 flex-1 justify-center">
            <Link href="/">
              <Button
                variant={location === "/" ? "secondary" : "ghost"}
                className="gap-2"
                data-testid="link-homepage"
              >
                <Home className="w-4 h-4" />
                الرئيسية
              </Button>
            </Link>
            <Link href="/technicians">
              <Button
                variant={location === "/technicians" ? "secondary" : "ghost"}
                className="gap-2"
                data-testid="link-technicians"
              >
                <User className="w-4 h-4" />
                الفنيين
              </Button>
            </Link>
          </div>

          {/* Auth Buttons - left side for RTL */}
          <div className="hidden md:flex items-center gap-2">
            {user ? (
              <>
                <span className="text-sm text-muted-foreground px-2" data-testid="text-username">
                  مرحباً، {user.name}
                </span>
                {user.role === "client" && (
                  <Link href="/client-dashboard">
                    <Button variant="outline" className="gap-2" data-testid="button-dashboard">
                      <LayoutDashboard className="w-4 h-4" />
                      لوحة التحكم
                    </Button>
                  </Link>
                )}
                {user.role === "technician" && (
                  <Link href="/technician-dashboard">
                    <Button variant="outline" className="gap-2" data-testid="button-dashboard">
                      <LayoutDashboard className="w-4 h-4" />
                      لوحة التحكم
                    </Button>
                  </Link>
                )}
                <Button 
                  variant="ghost" 
                  className="gap-2" 
                  onClick={handleLogout}
                  data-testid="button-logout"
                >
                  <LogOut className="w-4 h-4" />
                  خروج
                </Button>
              </>
            ) : (
              <>
                <Link href="/register">
                  <Button variant="outline" className="gap-2" data-testid="button-register">
                    <LogIn className="w-4 h-4" />
                    تسجيل جديد
                  </Button>
                </Link>
                <Link href="/login">
                  <Button className="gap-2" data-testid="button-login">
                    دخول
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-2">
              <Link href="/">
                <Button
                  variant={location === "/" ? "secondary" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setMobileMenuOpen(false)}
                  data-testid="link-homepage-mobile"
                >
                  <Home className="w-4 h-4" />
                  الرئيسية
                </Button>
              </Link>
              <Link href="/technicians">
                <Button
                  variant={location === "/technicians" ? "secondary" : "ghost"}
                  className="w-full justify-start gap-2"
                  onClick={() => setMobileMenuOpen(false)}
                  data-testid="link-technicians-mobile"
                >
                  <User className="w-4 h-4" />
                  الفنيين
                </Button>
              </Link>
              <div className="border-t border-border my-2" />
              {user ? (
                <>
                  <div className="px-4 py-2 text-sm text-muted-foreground">
                    مرحباً، {user.name}
                  </div>
                  {user.role === "client" && (
                    <Link href="/client-dashboard">
                      <Button
                        variant="outline"
                        className="w-full justify-start gap-2"
                        onClick={() => setMobileMenuOpen(false)}
                        data-testid="button-dashboard-mobile"
                      >
                        <LayoutDashboard className="w-4 h-4" />
                        لوحة التحكم
                      </Button>
                    </Link>
                  )}
                  {user.role === "technician" && (
                    <Link href="/technician-dashboard">
                      <Button
                        variant="outline"
                        className="w-full justify-start gap-2"
                        onClick={() => setMobileMenuOpen(false)}
                        data-testid="button-dashboard-mobile"
                      >
                        <LayoutDashboard className="w-4 h-4" />
                        لوحة التحكم
                      </Button>
                    </Link>
                  )}
                  <Button
                    variant="ghost"
                    className="w-full justify-start gap-2"
                    onClick={handleLogout}
                    data-testid="button-logout-mobile"
                  >
                    <LogOut className="w-4 h-4" />
                    خروج
                  </Button>
                </>
              ) : (
                <>
                  <Link href="/register">
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-2"
                      onClick={() => setMobileMenuOpen(false)}
                      data-testid="button-register-mobile"
                    >
                      <LogIn className="w-4 h-4" />
                      تسجيل جديد
                    </Button>
                  </Link>
                  <Link href="/login">
                    <Button
                      className="w-full justify-start gap-2"
                      onClick={() => setMobileMenuOpen(false)}
                      data-testid="button-login-mobile"
                    >
                      دخول
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
