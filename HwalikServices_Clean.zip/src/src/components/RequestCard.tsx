import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, User } from "lucide-react";

interface RequestCardProps {
  id: string;
  serviceType: string;
  technicianName?: string;
  description: string;
  status: "pending" | "accepted" | "rejected" | "completed";
  createdAt: string;
  onAccept?: (id: string) => void;
  onReject?: (id: string) => void;
  showActions?: boolean;
}

export default function RequestCard({
  id,
  serviceType,
  technicianName,
  description,
  status,
  createdAt,
  onAccept,
  onReject,
  showActions = false,
}: RequestCardProps) {
  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { label: "قيد المراجعة", variant: "secondary" as const },
      accepted: { label: "مقبولة", variant: "default" as const },
      rejected: { label: "مرفوضة", variant: "destructive" as const },
      completed: { label: "مكتملة", variant: "outline" as const },
    };
    return statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
  };

  const getServiceTypeArabic = (type: string) => {
    const types: Record<string, string> = {
      plumbing: "سباكة",
      electrical: "كهرباء",
      cleaning: "تنظيف",
      ac: "تكييف",
      painting: "دهان",
      carpentry: "نجارة",
    };
    return types[type] || type;
  };

  const statusInfo = getStatusBadge(status);

  return (
    <Card className="p-6" data-testid={`card-request-${id}`}>
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-semibold" data-testid={`text-service-type-${id}`}>
              {getServiceTypeArabic(serviceType)}
            </h3>
            <Badge variant={statusInfo.variant} data-testid={`badge-status-${id}`}>
              {statusInfo.label}
            </Badge>
          </div>
          {technicianName && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <User className="w-4 h-4" />
              <span data-testid={`text-technician-${id}`}>{technicianName}</span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span data-testid={`text-date-${id}`}>{createdAt}</span>
        </div>
      </div>

      <p className="text-muted-foreground mb-4" data-testid={`text-description-${id}`}>
        {description}
      </p>

      {showActions && status === "pending" && (
        <div className="flex gap-2">
          <Button
            className="flex-1"
            onClick={() => {
              console.log(`Accept request: ${id}`);
              onAccept?.(id);
            }}
            data-testid={`button-accept-${id}`}
          >
            قبول
          </Button>
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => {
              console.log(`Reject request: ${id}`);
              onReject?.(id);
            }}
            data-testid={`button-reject-${id}`}
          >
            رفض
          </Button>
        </div>
      )}
    </Card>
  );
}
