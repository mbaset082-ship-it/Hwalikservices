import RegistrationForm from '../RegistrationForm'

export default function RegistrationFormExample() {
  return <RegistrationForm />
}
