import TechnicianCard from '../TechnicianCard'

export default function TechnicianCardExample() {
  return (
    <div className="p-4 max-w-2xl">
      <TechnicianCard
        id="1"
        name="محمد أحمد"
        serviceType="plumbing"
        rating="4.8"
        priceRange="150-300"
        description="خبرة 10 سنوات في السباكة والصيانة المنزلية. متخصص في كشف التسربات وإصلاح الأعطال"
        location="الرياض"
        onRequestService={(id) => console.log('Request service:', id)}
      />
    </div>
  )
}
