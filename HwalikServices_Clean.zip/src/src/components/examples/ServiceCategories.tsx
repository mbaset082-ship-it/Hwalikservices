import ServiceCategories from '../ServiceCategories'

export default function ServiceCategoriesExample() {
  return <ServiceCategories />
}
