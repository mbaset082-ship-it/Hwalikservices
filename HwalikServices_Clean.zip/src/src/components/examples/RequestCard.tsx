import RequestCard from '../RequestCard'

export default function RequestCardExample() {
  return (
    <div className="p-4 max-w-2xl space-y-4">
      <RequestCard
        id="1"
        serviceType="plumbing"
        technicianName="محمد أحمد"
        description="تسريب في الحمام بحاجة لإصلاح عاجل"
        status="pending"
        createdAt="منذ ساعتين"
        showActions={true}
        onAccept={(id) => console.log('Accept:', id)}
        onReject={(id) => console.log('Reject:', id)}
      />
      <RequestCard
        id="2"
        serviceType="electrical"
        technicianName="خالد عبدالله"
        description="تركيب مصابيح في الصالة"
        status="accepted"
        createdAt="أمس"
        showActions={false}
      />
    </div>
  )
}
