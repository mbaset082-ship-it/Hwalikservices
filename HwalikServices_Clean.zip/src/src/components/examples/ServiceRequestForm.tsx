import ServiceRequestForm from '../ServiceRequestForm'

export default function ServiceRequestFormExample() {
  return (
    <ServiceRequestForm
      technicianId="1"
      technicianName="محمد أحمد"
      onSubmit={(data) => console.log('Request submitted:', data)}
    />
  )
}
