import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { Link } from "wouter";
import heroImage from "@assets/generated_images/Saudi_technician_at_home_cba3afd1.png";

export default function Hero() {
  return (
    <div className="relative h-[70vh] min-h-[500px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Dark Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-l from-primary/80 via-primary/60 to-primary/40" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 text-center">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6" data-testid="text-hero-title">
          خدمات منزلية موثوقة
          <br />
          بضغطة زر واحدة
        </h1>
        <p className="text-xl sm:text-2xl text-white/95 mb-8 max-w-2xl mx-auto" data-testid="text-hero-subtitle">
          احصل على أفضل الفنيين المحترفين في السعودية
          <br />
          سباكة • كهرباء • تنظيف • تكييف وأكثر
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
          <Link href="/register">
            <Button
              size="lg"
              className="text-lg px-8 bg-white text-primary hover:bg-white/90 border-2 border-white"
              data-testid="button-hero-register"
            >
              ابدأ الآن
            </Button>
          </Link>
          <Link href="/technicians">
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 bg-white/10 backdrop-blur-md text-white border-2 border-white/80 hover:bg-white/20"
              data-testid="button-hero-browse"
            >
              <Search className="w-5 h-5 ml-2" />
              تصفح الفنيين
            </Button>
          </Link>
        </div>

        {/* Trust Indicators */}
        <div className="flex flex-wrap gap-6 justify-center items-center text-white/90">
          <div className="text-center">
            <div className="text-3xl font-bold" data-testid="text-stat-technicians">500+</div>
            <div className="text-sm">فني محترف</div>
          </div>
          <div className="w-px h-12 bg-white/30 hidden sm:block" />
          <div className="text-center">
            <div className="text-3xl font-bold" data-testid="text-stat-services">10,000+</div>
            <div className="text-sm">خدمة منجزة</div>
          </div>
          <div className="w-px h-12 bg-white/30 hidden sm:block" />
          <div className="text-center">
            <div className="text-3xl font-bold" data-testid="text-stat-rating">4.8</div>
            <div className="text-sm">تقييم العملاء</div>
          </div>
        </div>
      </div>
    </div>
  );
}
