import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import ServiceCategories from "@/components/ServiceCategories";
import HowItWorks from "@/components/HowItWorks";
import Footer from "@/components/Footer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Clock, Award } from "lucide-react";
import { Link } from "wouter";

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <Hero />
      <ServiceCategories />
      <HowItWorks />

      {/* Featured Technicians Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-featured-title">
              فنيون مميزون
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-featured-subtitle">
              أفضل الفنيين ذوي التقييمات العالية
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {/* TODO: Replace with real technician data */}
            {["محمد أحمد", "خالد عبدالله", "أحمد سعيد"].map((name, idx) => (
              <Card key={idx} className="p-6 text-center hover-elevate" data-testid={`card-featured-${idx}`}>
                <div className="w-20 h-20 rounded-full bg-primary/10 text-primary flex items-center justify-center text-3xl font-bold mx-auto mb-4">
                  {name.charAt(0)}
                </div>
                <h3 className="font-semibold text-lg mb-2" data-testid={`text-featured-name-${idx}`}>{name}</h3>
                <p className="text-muted-foreground mb-4">فني سباكة محترف</p>
                <div className="flex items-center justify-center gap-1 text-yellow-600 mb-4">
                  <span className="font-semibold">4.9</span>
                  <span className="text-sm">⭐</span>
                </div>
                <Link href="/technicians">
                  <Button variant="outline" className="w-full" data-testid={`button-view-profile-${idx}`}>
                    عرض الملف الشخصي
                  </Button>
                </Link>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Link href="/technicians">
              <Button size="lg" data-testid="button-view-all">
                عرض جميع الفنيين
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-trust-title">
              لماذا حوليك؟
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center" data-testid="feature-verified">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                <Shield className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">فنيون موثوقون</h3>
              <p className="text-muted-foreground">
                جميع الفنيين تم التحقق من هوياتهم وخبراتهم
              </p>
            </div>

            <div className="text-center" data-testid="feature-fast">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                <Clock className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">استجابة سريعة</h3>
              <p className="text-muted-foreground">
                احصل على رد خلال دقائق من إرسال طلبك
              </p>
            </div>

            <div className="text-center" data-testid="feature-quality">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                <Award className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-3">جودة مضمونة</h3>
              <p className="text-muted-foreground">
                نضمن جودة الخدمة أو نعيد أموالك بالكامل
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-cta-title">
            جاهز لبدء طلب خدمتك؟
          </h2>
          <p className="text-xl mb-8 opacity-90" data-testid="text-cta-subtitle">
            انضم لآلاف العملاء الراضين عن خدماتنا
          </p>
          <Link href="/register">
            <Button
              size="lg"
              className="text-lg px-8 bg-white text-primary hover:bg-white/90 border-2 border-white"
              data-testid="button-cta-register"
            >
              سجل مجاناً الآن
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
