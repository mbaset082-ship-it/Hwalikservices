import RegistrationForm from "@/components/RegistrationForm";

export default function RegisterPage() {
  return <RegistrationForm />;
}
