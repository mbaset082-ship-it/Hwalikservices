import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import TechnicianCard from "@/components/TechnicianCard";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLocation } from "wouter";

export default function TechniciansPage() {
  const [, setLocation] = useLocation();
  const [serviceFilter, setServiceFilter] = useState<string>("all");

  const { data: technicians = [], isLoading } = useQuery({
    queryKey: ["/api/technicians", serviceFilter],
    queryFn: async () => {
      const url = serviceFilter === "all" 
        ? "/api/technicians"
        : `/api/technicians?serviceType=${serviceFilter}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("فشل تحميل الفنيين");
      return res.json();
    },
  });

  const handleRequestService = (technicianId: string) => {
    setLocation(`/request-service?technicianId=${technicianId}`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-1 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4" data-testid="text-page-title">
              تصفح الفنيين
            </h1>
            <p className="text-lg text-muted-foreground" data-testid="text-page-subtitle">
              اختر الفني المناسب لاحتياجاتك
            </p>
          </div>

          {/* Filters */}
          <div className="bg-card p-6 rounded-lg border border-card-border mb-8">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="serviceType" data-testid="label-filter">نوع الخدمة</Label>
                <Select value={serviceFilter} onValueChange={setServiceFilter}>
                  <SelectTrigger id="serviceType" data-testid="select-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الخدمات</SelectItem>
                    <SelectItem value="plumbing">سباكة</SelectItem>
                    <SelectItem value="electrical">كهرباء</SelectItem>
                    <SelectItem value="cleaning">تنظيف</SelectItem>
                    <SelectItem value="ac">تكييف</SelectItem>
                    <SelectItem value="painting">دهان</SelectItem>
                    <SelectItem value="carpentry">نجارة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Results Count */}
          {!isLoading && (
            <div className="mb-6">
              <p className="text-muted-foreground" data-testid="text-results-count">
                عرض {technicians.length} فني
              </p>
            </div>
          )}

          {/* Technicians Grid */}
          {isLoading ? (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">جاري التحميل...</p>
            </div>
          ) : technicians.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-6">
              {technicians.map((technician: any) => (
                <TechnicianCard
                  key={technician.id}
                  id={technician.id}
                  name={technician.name}
                  serviceType={technician.serviceType}
                  rating={technician.rating || "0"}
                  priceRange={technician.priceRange || ""}
                  description={technician.description || ""}
                  onRequestService={handleRequestService}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground" data-testid="text-no-results">
                لا توجد نتائج لهذا الفلتر
              </p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => setServiceFilter("all")}
                data-testid="button-clear-filter"
              >
                إعادة تعيين الفلتر
              </Button>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
