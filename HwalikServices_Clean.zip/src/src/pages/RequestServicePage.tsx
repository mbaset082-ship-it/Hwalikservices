import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/auth-context";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function RequestServicePage() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const params = new URLSearchParams(location.split("?")[1]);
  const technicianId = params.get("technicianId");

  const [serviceType, setServiceType] = useState("");
  const [description, setDescription] = useState("");

  const { data: technician } = useQuery({
    queryKey: ["/api/technicians", technicianId],
    queryFn: async () => {
      if (!technicianId) return null;
      const res = await fetch(`/api/technicians/${technicianId}`);
      if (!res.ok) throw new Error("فشل تحميل بيانات الفني");
      return res.json();
    },
    enabled: !!technicianId,
  });

  const createRequestMutation = useMutation({
    mutationFn: async (data: { serviceType: string; description: string }) => {
      if (!user) throw new Error("يجب تسجيل الدخول أولاً");
      if (!technicianId) throw new Error("يجب اختيار فني");

      return apiRequest("POST", `/api/requests`, {
        clientId: user.id,
        technicianId,
        serviceType: data.serviceType,
        description: data.description,
        status: "pending",
      });
    },
    onSuccess: () => {
      toast({
        title: "تم إرسال الطلب بنجاح",
        description: "سيتم إشعارك عندما يقبل الفني الطلب",
      });
      setLocation("/client-dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ في إرسال الطلب",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "تنبيه",
        description: "يجب تسجيل الدخول أولاً",
        variant: "destructive",
      });
      setLocation("/login");
      return;
    }

    createRequestMutation.mutate({ serviceType, description });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4 py-8">
      <Card className="w-full max-w-2xl p-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2" data-testid="text-request-title">
            طلب خدمة جديدة
          </h2>
          {technician && (
            <p className="text-muted-foreground" data-testid="text-technician-name">
              من الفني: {technician.name}
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Service Type */}
          <div className="space-y-2">
            <Label htmlFor="serviceType" data-testid="label-service-type">نوع الخدمة</Label>
            <Select value={serviceType} onValueChange={setServiceType} required>
              <SelectTrigger id="serviceType" data-testid="select-service-type">
                <SelectValue placeholder="اختر نوع الخدمة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="plumbing">سباكة</SelectItem>
                <SelectItem value="electrical">كهرباء</SelectItem>
                <SelectItem value="cleaning">تنظيف</SelectItem>
                <SelectItem value="ac">تكييف</SelectItem>
                <SelectItem value="painting">دهان</SelectItem>
                <SelectItem value="carpentry">نجارة</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" data-testid="label-description">وصف المشكلة</Label>
            <Textarea
              id="description"
              placeholder="اشرح تفاصيل الخدمة المطلوبة..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              required
              data-testid="textarea-description"
            />
            <p className="text-sm text-muted-foreground">
              اشرح المشكلة بالتفصيل لمساعدة الفني على فهم احتياجاتك
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button 
              type="submit" 
              className="flex-1" 
              size="lg" 
              disabled={createRequestMutation.isPending}
              data-testid="button-submit"
            >
              {createRequestMutation.isPending ? "جاري الإرسال..." : "إرسال الطلب"}
            </Button>
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              size="lg"
              onClick={() => window.history.back()}
              data-testid="button-cancel"
            >
              إلغاء
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
