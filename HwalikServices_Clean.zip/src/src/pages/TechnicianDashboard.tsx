import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import RequestCard from "@/components/RequestCard";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth-context";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function TechnicianDashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Handle redirects in useEffect
  useEffect(() => {
    if (authLoading) return;
    
    if (!user) {
      setLocation("/login");
      return;
    }

    if (user.role !== "technician") {
      setLocation("/client-dashboard");
      return;
    }
  }, [authLoading, user, setLocation]);

  // Get technician profile first
  const { data: technician } = useQuery({
    queryKey: ["/api/technicians/profile", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const allTechnicians = await fetch("/api/technicians").then(res => res.json());
      return allTechnicians.find((t: any) => t.userId === user.id);
    },
    enabled: !!user,
  });

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["/api/requests/technician", technician?.id],
    queryFn: async () => {
      if (!technician) return [];
      const res = await fetch(`/api/requests/technician/${technician.id}`);
      if (!res.ok) throw new Error("فشل تحميل الطلبات");
      return res.json();
    },
    enabled: !!technician,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ requestId, status }: { requestId: string; status: string }) => {
      return apiRequest("PATCH", `/api/requests/${requestId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/technician"] });
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Show loading while auth is initializing or redirecting
  if (authLoading || !user || user.role !== "technician" || !technician) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-muted-foreground">جاري التحميل...</p>
      </div>
    );
  }

  const handleAccept = (id: string) => {
    updateStatusMutation.mutate(
      { requestId: id, status: "accepted" },
      {
        onSuccess: () => {
          toast({
            title: "تم قبول الطلب",
            description: "تم قبول طلب الخدمة بنجاح",
          });
        },
      }
    );
  };

  const handleReject = (id: string) => {
    updateStatusMutation.mutate(
      { requestId: id, status: "rejected" },
      {
        onSuccess: () => {
          toast({
            title: "تم رفض الطلب",
            description: "تم رفض طلب الخدمة",
            variant: "destructive",
          });
        },
      }
    );
  };

  const pendingRequests = requests.filter((r: any) => r.status === "pending");
  const upcomingRequests = requests.filter((r: any) => r.status === "accepted");
  const completedRequests = requests.filter((r: any) => r.status === "completed");

  const formatDate = (dateString: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    if (diffDays === 1) return "أمس";
    if (diffDays < 7) return `منذ ${diffDays} أيام`;
    return date.toLocaleDateString("ar-SA");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-1 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2" data-testid="text-dashboard-title">
              لوحة التحكم - الفني
            </h1>
            <p className="text-lg text-muted-foreground" data-testid="text-dashboard-subtitle">
              إدارة طلبات الخدمات الواردة
            </p>
          </div>

          {/* Stats Cards */}
          {!isLoading && (
            <div className="grid md:grid-cols-4 gap-4 mb-8">
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-pending">
                <div className="text-3xl font-bold text-yellow-600 mb-2">{pendingRequests.length}</div>
                <div className="text-sm text-muted-foreground">طلبات جديدة</div>
              </div>
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-upcoming">
                <div className="text-3xl font-bold text-primary mb-2">{upcomingRequests.length}</div>
                <div className="text-sm text-muted-foreground">خدمات قادمة</div>
              </div>
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-completed">
                <div className="text-3xl font-bold text-green-600 mb-2">{completedRequests.length}</div>
                <div className="text-sm text-muted-foreground">مكتملة</div>
              </div>
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-earnings">
                <div className="text-3xl font-bold text-blue-600 mb-2">
                  {completedRequests.length * 250}
                </div>
                <div className="text-sm text-muted-foreground">الأرباح التقديرية (ريال)</div>
              </div>
            </div>
          )}

          {/* Requests List */}
          {isLoading ? (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">جاري التحميل...</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Pending Requests */}
              {pendingRequests.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold mb-4" data-testid="text-pending-title">
                    طلبات جديدة - بانتظار الرد
                  </h2>
                  <div className="space-y-4">
                    {pendingRequests.map((request: any) => (
                      <RequestCard
                        key={request.id}
                        id={request.id}
                        serviceType={request.serviceType}
                        description={request.description}
                        status={request.status}
                        createdAt={formatDate(request.createdAt)}
                        showActions={true}
                        onAccept={handleAccept}
                        onReject={handleReject}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Upcoming Services */}
              {upcomingRequests.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold mb-4" data-testid="text-upcoming-title">
                    خدمات قادمة
                  </h2>
                  <div className="space-y-4">
                    {upcomingRequests.map((request: any) => (
                      <RequestCard
                        key={request.id}
                        id={request.id}
                        serviceType={request.serviceType}
                        description={request.description}
                        status={request.status}
                        createdAt={formatDate(request.createdAt)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Completed Services */}
              {completedRequests.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold mb-4" data-testid="text-completed-title">
                    خدمات مكتملة
                  </h2>
                  <div className="space-y-4">
                    {completedRequests.map((request: any) => (
                      <RequestCard
                        key={request.id}
                        id={request.id}
                        serviceType={request.serviceType}
                        description={request.description}
                        status={request.status}
                        createdAt={formatDate(request.createdAt)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {requests.length === 0 && (
                <div className="text-center py-16">
                  <p className="text-xl text-muted-foreground" data-testid="text-no-requests">
                    لا توجد طلبات حالياً
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
