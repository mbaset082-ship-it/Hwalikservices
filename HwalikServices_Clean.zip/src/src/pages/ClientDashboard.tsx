import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import RequestCard from "@/components/RequestCard";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";

export default function ClientDashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Handle redirects in useEffect
  useEffect(() => {
    if (authLoading) return;
    
    if (!user) {
      setLocation("/login");
      return;
    }

    if (user.role !== "client") {
      setLocation("/technician-dashboard");
      return;
    }
  }, [authLoading, user, setLocation]);

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["/api/requests/client", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const res = await fetch(`/api/requests/client/${user.id}`);
      if (!res.ok) throw new Error("فشل تحميل الطلبات");
      return res.json();
    },
    enabled: !!user,
  });

  // Show loading while auth is initializing or redirecting
  if (authLoading || !user || user.role !== "client") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-muted-foreground">جاري التحميل...</p>
      </div>
    );
  }

  const pendingRequests = requests.filter((r: any) => r.status === "pending");
  const activeRequests = requests.filter((r: any) => r.status === "accepted");
  const completedRequests = requests.filter((r: any) => r.status === "completed");

  const formatDate = (dateString: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    if (diffDays === 1) return "أمس";
    if (diffDays < 7) return `منذ ${diffDays} أيام`;
    return date.toLocaleDateString("ar-SA");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-1 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold mb-2" data-testid="text-dashboard-title">
                لوحة التحكم - العميل
              </h1>
              <p className="text-lg text-muted-foreground" data-testid="text-dashboard-subtitle">
                إدارة طلبات الخدمات
              </p>
            </div>
            <Link href="/technicians">
              <Button className="gap-2" data-testid="button-new-request">
                <Plus className="w-4 h-4" />
                طلب جديد
              </Button>
            </Link>
          </div>

          {/* Stats Cards */}
          {!isLoading && (
            <div className="grid md:grid-cols-4 gap-4 mb-8">
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-total">
                <div className="text-3xl font-bold text-primary mb-2">{requests.length}</div>
                <div className="text-sm text-muted-foreground">إجمالي الطلبات</div>
              </div>
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-pending">
                <div className="text-3xl font-bold text-yellow-600 mb-2">{pendingRequests.length}</div>
                <div className="text-sm text-muted-foreground">قيد المراجعة</div>
              </div>
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-active">
                <div className="text-3xl font-bold text-green-600 mb-2">{activeRequests.length}</div>
                <div className="text-sm text-muted-foreground">نشطة</div>
              </div>
              <div className="bg-card p-6 rounded-lg border border-card-border" data-testid="stat-completed">
                <div className="text-3xl font-bold text-blue-600 mb-2">{completedRequests.length}</div>
                <div className="text-sm text-muted-foreground">مكتملة</div>
              </div>
            </div>
          )}

          {/* Requests List */}
          {isLoading ? (
            <div className="text-center py-16">
              <p className="text-xl text-muted-foreground">جاري التحميل...</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Pending Requests */}
              {pendingRequests.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold mb-4" data-testid="text-pending-title">
                    طلبات قيد المراجعة
                  </h2>
                  <div className="space-y-4">
                    {pendingRequests.map((request: any) => (
                      <RequestCard
                        key={request.id}
                        id={request.id}
                        serviceType={request.serviceType}
                        technicianName={request.technicianName}
                        description={request.description}
                        status={request.status}
                        createdAt={formatDate(request.createdAt)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Active Requests */}
              {activeRequests.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold mb-4" data-testid="text-active-title">
                    طلبات نشطة
                  </h2>
                  <div className="space-y-4">
                    {activeRequests.map((request: any) => (
                      <RequestCard
                        key={request.id}
                        id={request.id}
                        serviceType={request.serviceType}
                        technicianName={request.technicianName}
                        description={request.description}
                        status={request.status}
                        createdAt={formatDate(request.createdAt)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Completed Requests */}
              {completedRequests.length > 0 && (
                <div>
                  <h2 className="text-2xl font-bold mb-4" data-testid="text-completed-title">
                    طلبات مكتملة
                  </h2>
                  <div className="space-y-4">
                    {completedRequests.map((request: any) => (
                      <RequestCard
                        key={request.id}
                        id={request.id}
                        serviceType={request.serviceType}
                        technicianName={request.technicianName}
                        description={request.description}
                        status={request.status}
                        createdAt={formatDate(request.createdAt)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {requests.length === 0 && (
                <div className="text-center py-16">
                  <p className="text-xl text-muted-foreground mb-4" data-testid="text-no-requests">
                    لا توجد طلبات حالياً
                  </p>
                  <Link href="/technicians">
                    <Button data-testid="button-browse-technicians">
                      تصفح الفنيين
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
