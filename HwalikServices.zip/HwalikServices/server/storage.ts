import { 
  type User, 
  type InsertUser, 
  type Technician, 
  type InsertTechnician,
  type ServiceRequest,
  type InsertServiceRequest 
} from "@shared/schema";
import { randomUUID } from "crypto";

// Storage interface with all CRUD operations needed for the application
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Technician operations
  getTechnician(id: string): Promise<Technician | undefined>;
  getTechnicianByUserId(userId: string): Promise<Technician | undefined>;
  createTechnician(technician: InsertTechnician): Promise<Technician>;
  getAllTechnicians(): Promise<Technician[]>;
  getTechniciansByServiceType(serviceType: string): Promise<Technician[]>;

  // Service request operations
  getServiceRequest(id: string): Promise<ServiceRequest | undefined>;
  createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest>;
  getAllServiceRequests(): Promise<ServiceRequest[]>;
  getServiceRequestsByClientId(clientId: string): Promise<ServiceRequest[]>;
  getServiceRequestsByTechnicianId(technicianId: string): Promise<ServiceRequest[]>;
  updateServiceRequestStatus(id: string, status: string): Promise<ServiceRequest | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private technicians: Map<string, Technician>;
  private serviceRequests: Map<string, ServiceRequest>;

  constructor() {
    this.users = new Map();
    this.technicians = new Map();
    this.serviceRequests = new Map();
    
    // Seed with sample data for demo purposes
    this.seedData();
  }

  // Seed sample data for demo
  private async seedData() {
    // Create sample technicians
    const sampleTechnicians = [
      { name: "محمد أحمد", phone: "0501234567", serviceType: "plumbing", description: "خبرة 10 سنوات في السباكة والصيانة المنزلية. متخصص في كشف التسربات وإصلاح الأعطال", priceRange: "150-300" },
      { name: "خالد عبدالله", phone: "0501234568", serviceType: "electrical", description: "كهربائي معتمد مع خبرة 8 سنوات. تركيب وصيانة جميع الأنظمة الكهربائية", priceRange: "200-400" },
      { name: "أحمد سعيد", phone: "0501234569", serviceType: "cleaning", description: "خدمات تنظيف شاملة للمنازل والمكاتب بأحدث المعدات", priceRange: "100-250" },
      { name: "عبدالرحمن فهد", phone: "0501234570", serviceType: "ac", description: "فني تكييف وتبريد. صيانة وتركيب جميع أنواع المكيفات", priceRange: "180-350" },
      { name: "سعود محمد", phone: "0501234571", serviceType: "painting", description: "دهان محترف للمنازل والمكاتب. ألوان عصرية ونتائج مميزة", priceRange: "120-280" },
      { name: "فيصل عبدالعزيز", phone: "0501234572", serviceType: "carpentry", description: "نجار ماهر في صناعة وإصلاح الأثاث المنزلي والمكتبي", priceRange: "200-450" },
    ];

    for (const tech of sampleTechnicians) {
      const user = await this.createUser({
        name: tech.name,
        phone: tech.phone,
        role: "technician",
        password: "password123", // Demo password
      });

      await this.createTechnician({
        userId: user.id,
        serviceType: tech.serviceType,
        description: tech.description,
        priceRange: tech.priceRange,
        rating: "4.8",
      });
    }
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.phone === phone,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Technician operations
  async getTechnician(id: string): Promise<Technician | undefined> {
    return this.technicians.get(id);
  }

  async getTechnicianByUserId(userId: string): Promise<Technician | undefined> {
    return Array.from(this.technicians.values()).find(
      (tech) => tech.userId === userId,
    );
  }

  async createTechnician(insertTechnician: InsertTechnician): Promise<Technician> {
    const id = randomUUID();
    const technician: Technician = { 
      ...insertTechnician, 
      id,
      description: insertTechnician.description ?? null,
      priceRange: insertTechnician.priceRange ?? null,
      rating: insertTechnician.rating ?? null,
    };
    this.technicians.set(id, technician);
    return technician;
  }

  async getAllTechnicians(): Promise<Technician[]> {
    return Array.from(this.technicians.values());
  }

  async getTechniciansByServiceType(serviceType: string): Promise<Technician[]> {
    return Array.from(this.technicians.values()).filter(
      (tech) => tech.serviceType === serviceType,
    );
  }

  // Service request operations
  async getServiceRequest(id: string): Promise<ServiceRequest | undefined> {
    return this.serviceRequests.get(id);
  }

  async createServiceRequest(insertRequest: InsertServiceRequest): Promise<ServiceRequest> {
    const id = randomUUID();
    const request: ServiceRequest = { 
      ...insertRequest, 
      id,
      status: insertRequest.status ?? "pending",
      createdAt: new Date(),
    };
    this.serviceRequests.set(id, request);
    return request;
  }

  async getAllServiceRequests(): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequests.values());
  }

  async getServiceRequestsByClientId(clientId: string): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequests.values()).filter(
      (req) => req.clientId === clientId,
    );
  }

  async getServiceRequestsByTechnicianId(technicianId: string): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequests.values()).filter(
      (req) => req.technicianId === technicianId,
    );
  }

  async updateServiceRequestStatus(id: string, status: string): Promise<ServiceRequest | undefined> {
    const request = this.serviceRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest = { ...request, status };
    this.serviceRequests.set(id, updatedRequest);
    return updatedRequest;
  }
}

export const storage = new MemStorage();
