import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertTechnicianSchema, insertServiceRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // User registration endpoint
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if phone already exists
      const existingUser = await storage.getUserByPhone(userData.phone);
      if (existingUser) {
        return res.status(400).json({ error: "رقم الجوال مسجل مسبقاً" });
      }

      // If technician, validate technician data before creating user
      if (userData.role === "technician") {
        if (!req.body.technicianData) {
          return res.status(400).json({ error: "بيانات الفني مطلوبة للتسجيل كفني" });
        }
        
        // Validate technician data schema early
        insertTechnicianSchema.parse({
          userId: "temp", // Will be replaced with actual userId
          ...req.body.technicianData,
        });
      }

      // Create user
      const user = await storage.createUser(userData);

      // Create technician profile if role is technician
      if (userData.role === "technician") {
        const technicianData = insertTechnicianSchema.parse({
          userId: user.id,
          ...req.body.technicianData,
        });
        await storage.createTechnician(technicianData);
      }

      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "بيانات غير صحيحة", details: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ أثناء إنشاء الحساب" });
    }
  });

  // Login endpoint
  app.post("/api/login", async (req, res) => {
    try {
      const { phone, password } = req.body;
      
      if (!phone || !password) {
        return res.status(400).json({ error: "رقم الجوال وكلمة المرور مطلوبان" });
      }

      const user = await storage.getUserByPhone(phone);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "رقم الجوال أو كلمة المرور غير صحيحة" });
      }

      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ أثناء تسجيل الدخول" });
    }
  });

  // Get all technicians with user details
  app.get("/api/technicians", async (req, res) => {
    try {
      const { serviceType } = req.query;
      
      let technicians = serviceType && serviceType !== "all"
        ? await storage.getTechniciansByServiceType(serviceType as string)
        : await storage.getAllTechnicians();

      // Get user details for each technician
      const techniciansWithUsers = await Promise.all(
        technicians.map(async (tech) => {
          const user = await storage.getUser(tech.userId);
          return {
            ...tech,
            name: user?.name,
            phone: user?.phone,
          };
        })
      );

      res.json(techniciansWithUsers);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ أثناء جلب الفنيين" });
    }
  });

  // Get single technician
  app.get("/api/technicians/:id", async (req, res) => {
    try {
      const technician = await storage.getTechnician(req.params.id);
      
      if (!technician) {
        return res.status(404).json({ error: "الفني غير موجود" });
      }

      const user = await storage.getUser(technician.userId);
      
      res.json({
        ...technician,
        name: user?.name,
        phone: user?.phone,
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ أثناء جلب بيانات الفني" });
    }
  });

  // Create service request
  app.post("/api/requests", async (req, res) => {
    try {
      const requestData = insertServiceRequestSchema.parse(req.body);
      
      // Verify client exists
      const client = await storage.getUser(requestData.clientId);
      if (!client) {
        return res.status(400).json({ error: "العميل غير موجود" });
      }
      
      // Verify technician exists
      const technician = await storage.getTechnician(requestData.technicianId);
      if (!technician) {
        return res.status(400).json({ error: "الفني غير موجود" });
      }
      
      const request = await storage.createServiceRequest(requestData);
      res.json(request);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "بيانات غير صحيحة", details: error.errors });
      }
      res.status(500).json({ error: "حدث خطأ أثناء إنشاء الطلب" });
    }
  });

  // Get service requests for a client
  app.get("/api/requests/client/:clientId", async (req, res) => {
    try {
      const requests = await storage.getServiceRequestsByClientId(req.params.clientId);
      
      // Get technician details for each request
      const requestsWithDetails = await Promise.all(
        requests.map(async (request) => {
          const technician = await storage.getTechnician(request.technicianId);
          const user = technician ? await storage.getUser(technician.userId) : null;
          
          return {
            ...request,
            technicianName: user?.name,
            createdAt: request.createdAt?.toISOString(),
          };
        })
      );

      res.json(requestsWithDetails);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ أثناء جلب الطلبات" });
    }
  });

  // Get service requests for a technician
  app.get("/api/requests/technician/:technicianId", async (req, res) => {
    try {
      const requests = await storage.getServiceRequestsByTechnicianId(req.params.technicianId);
      
      // Get client details for each request
      const requestsWithDetails = await Promise.all(
        requests.map(async (request) => {
          const client = await storage.getUser(request.clientId);
          
          return {
            ...request,
            clientName: client?.name,
            createdAt: request.createdAt?.toISOString(),
          };
        })
      );

      res.json(requestsWithDetails);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ أثناء جلب الطلبات" });
    }
  });

  // Update service request status (accept/reject)
  app.patch("/api/requests/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      
      if (!["pending", "accepted", "rejected", "completed"].includes(status)) {
        return res.status(400).json({ error: "حالة غير صحيحة" });
      }

      const updatedRequest = await storage.updateServiceRequestStatus(req.params.id, status);
      
      if (!updatedRequest) {
        return res.status(404).json({ error: "الطلب غير موجود" });
      }

      res.json(updatedRequest);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ أثناء تحديث الطلب" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
